--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1 (Debian 17.1-1.pgdg120+1)
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Staff_management";
--
-- Name: Staff_management; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "Staff_management" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\unrestrict (null)
\connect "Staff_management"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    deptid integer NOT NULL,
    deptname character varying(100) NOT NULL,
    building character varying(50) NOT NULL,
    floor integer NOT NULL,
    CONSTRAINT chk_floor CHECK (((floor >= '-5'::integer) AND (floor <= 20)))
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    roleid integer NOT NULL,
    rolename character varying(100) NOT NULL,
    basehourlysalary numeric(10,2) NOT NULL,
    description text,
    CONSTRAINT chk_salary_pos CHECK ((basehourlysalary > (0)::numeric))
);


--
-- Name: salaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salaries (
    salaryid integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    paymentdate date NOT NULL,
    baseamount numeric(10,2) NOT NULL,
    bonusamount numeric(10,2) DEFAULT 0,
    overtimehours numeric(5,2) DEFAULT 0,
    staffid integer NOT NULL,
    CONSTRAINT chk_month_range CHECK (((month >= 1) AND (month <= 12))),
    CONSTRAINT chk_positive_pay CHECK (((baseamount >= (0)::numeric) AND (bonusamount >= (0)::numeric))),
    CONSTRAINT chk_year_min CHECK ((year > 2020))
);


--
-- Name: shiftassignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shiftassignments (
    assignmentid integer NOT NULL,
    workdate date NOT NULL,
    starttime time without time zone NOT NULL,
    endtime time without time zone NOT NULL,
    staffid integer NOT NULL,
    shiftid integer NOT NULL,
    deptid integer NOT NULL,
    CONSTRAINT chk_work_times CHECK ((endtime > starttime))
);


--
-- Name: shifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shifts (
    shiftid integer NOT NULL,
    shifttype character varying(50) NOT NULL,
    startshift time without time zone NOT NULL,
    endshift time without time zone NOT NULL,
    shiftmultiplier numeric(3,2) NOT NULL,
    CONSTRAINT chk_mult_min CHECK ((shiftmultiplier >= 1.0))
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff (
    staffid integer NOT NULL,
    firstname character varying(100) NOT NULL,
    lastname character varying(100) NOT NULL,
    idnumber character varying(20) NOT NULL,
    phone character varying(20),
    status character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    hiredate date NOT NULL,
    deptid integer NOT NULL,
    roleid integer NOT NULL,
    CONSTRAINT chk_status_vals CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'Inactive'::character varying, 'On Leave'::character varying])::text[])))
);


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (deptid, deptname, building, floor) FROM stdin;
\.
COPY public.departments (deptid, deptname, building, floor) FROM '$$PATH$$/3406.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (roleid, rolename, basehourlysalary, description) FROM stdin;
\.
COPY public.roles (roleid, rolename, basehourlysalary, description) FROM '$$PATH$$/3407.dat';

--
-- Data for Name: salaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.salaries (salaryid, month, year, paymentdate, baseamount, bonusamount, overtimehours, staffid) FROM stdin;
\.
COPY public.salaries (salaryid, month, year, paymentdate, baseamount, bonusamount, overtimehours, staffid) FROM '$$PATH$$/3411.dat';

--
-- Data for Name: shiftassignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shiftassignments (assignmentid, workdate, starttime, endtime, staffid, shiftid, deptid) FROM stdin;
\.
COPY public.shiftassignments (assignmentid, workdate, starttime, endtime, staffid, shiftid, deptid) FROM '$$PATH$$/3410.dat';

--
-- Data for Name: shifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shifts (shiftid, shifttype, startshift, endshift, shiftmultiplier) FROM stdin;
\.
COPY public.shifts (shiftid, shifttype, startshift, endshift, shiftmultiplier) FROM '$$PATH$$/3409.dat';

--
-- Data for Name: staff; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.staff (staffid, firstname, lastname, idnumber, phone, status, email, hiredate, deptid, roleid) FROM stdin;
\.
COPY public.staff (staffid, firstname, lastname, idnumber, phone, status, email, hiredate, deptid, roleid) FROM '$$PATH$$/3408.dat';

--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (deptid);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (roleid);


--
-- Name: salaries salaries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_pkey PRIMARY KEY (salaryid);


--
-- Name: shiftassignments shiftassignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shiftassignments
    ADD CONSTRAINT shiftassignments_pkey PRIMARY KEY (assignmentid);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (shiftid);


--
-- Name: staff staff_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_email_key UNIQUE (email);


--
-- Name: staff staff_idnumber_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_idnumber_key UNIQUE (idnumber);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (staffid);


--
-- Name: salaries salaries_staffid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salaries
    ADD CONSTRAINT salaries_staffid_fkey FOREIGN KEY (staffid) REFERENCES public.staff(staffid);


--
-- Name: shiftassignments shiftassignments_deptid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shiftassignments
    ADD CONSTRAINT shiftassignments_deptid_fkey FOREIGN KEY (deptid) REFERENCES public.departments(deptid);


--
-- Name: shiftassignments shiftassignments_shiftid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shiftassignments
    ADD CONSTRAINT shiftassignments_shiftid_fkey FOREIGN KEY (shiftid) REFERENCES public.shifts(shiftid);


--
-- Name: shiftassignments shiftassignments_staffid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shiftassignments
    ADD CONSTRAINT shiftassignments_staffid_fkey FOREIGN KEY (staffid) REFERENCES public.staff(staffid);


--
-- Name: staff staff_deptid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_deptid_fkey FOREIGN KEY (deptid) REFERENCES public.departments(deptid);


--
-- Name: staff staff_roleid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_roleid_fkey FOREIGN KEY (roleid) REFERENCES public.roles(roleid);


--
-- PostgreSQL database dump complete
--

